let login = document.querySelector('#login');

login.addEventListener('click', function () {
    login.innerText = 'logout';
})

let Add = document.querySelector('.Add');

Add.addEventListener('click', function () {
    Add.style.display = 'none';
})